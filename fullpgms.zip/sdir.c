#include<stdio.h>
#include<string.h>
struct
{
	char dirname[10],fname[10][10];
	int fnum;
}dir;

void main()
{
	printf("Enter the directory name:\n");
	scanf("%s",dir.dirname);
	int i,n,c=0;
	char ser[10];
	dir.fnum=0;
	do
	{
		printf("MENU\n1.Create file\n2.Search File\n3.Delete file\n4.Display\n");
		printf("Enter your choice:");
		scanf("%d",&n);
		switch(n)
		{
			case 1:
			{
				printf("Enter the file name:\n");
				scanf("%s",dir.fname[dir.fnum]);
				dir.fnum++;
				break;
			}
			case 2:
			{
				printf("Enter the file name to be searched:\n");
				scanf("%s",ser);
				for(i=0;i<dir.fnum;i++)
				{
				   	if(strcmp(ser,dir.fname[i])==0)
					{
						printf("File found at location %d\n",i);
						break;
					}
				}
				if(i==dir.fnum)
					printf("File not found\n");
				break;
			}
			case 3:
			{
				printf("Enter the file name to be deleted:\n");
				scanf("%s",ser);
				for(i=0;i<dir.fnum;i++)
				{
					if(strcmp(ser,dir.fname[i])==0)
					{
						printf("File deleted\n");
						strcpy(dir.fname[i],dir.fname[dir.fnum-1]);
						dir.fnum--;
					}
				}
				break;
			}
			case 4:
			{
				if(dir.fnum==0)
				{
					printf("Directory Empty\n");
				}
				else
				{
					printf("The files are:\n");
					for(i=0;i<dir.fnum;i++)
					{
						printf("%s\n",dir.fname[i]);
	      				}
				}
				break;
			}
			default:printf("invalid option\n");
		}
		printf("Enter 1 to return to menu:\n");
		scanf("%d",&c);
	}while(c==1);
}
