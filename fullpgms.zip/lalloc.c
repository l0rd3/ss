#include<stdio.h>
void main()
{
	int f[50],m[3][10],p,i,j,k,a,l,c=1,fi=0;
	for(i=0;i<50;i++)
		f[i]=-1;
	printf("Enter no of blocks that are already allocated:");
	scanf("%d",&p);
	printf("Enter the block's that are already allocated:");
	for(i=0;i<p;i++)
	{
		scanf("%d",&a);
		f[a]=0;
	}
	p=50-p;
	do
	{
		printf("Enter the length of file:");
		scanf("%d",&l);
		k=0;
		if(l<=p)
		{
			fi++;
			for(j=0;j<50;j++)
			{
				if((f[j]==-1)&&(k<l))
				{
					f[j]=fi;
					printf("\n%d\tallocated",j);
					k++;
					if(k==1)
					{
						m[0][fi-1]=j;
						m[1][fi-1]=l;
					}
					if(k==l)
					{
						printf("\nFile allocated.\n");
						m[2][fi-1]=j;
						p=p-l;
						break;
					}
				}
			}
		}
		else
		{
			printf("\nSize exceeded.File cannot be allocated.\n");
		}
		printf("\nInput more files?yes-1,no-0:\t");
		scanf("%d",&c);
	}while(c==1);
	printf("File Number\tStart address\tEnd Addresss\tLength\n");
	for(i=0;i<fi;i++)
	{
		printf("%d\t\t%d\t\t%d\t\t%d\n",i+1,m[0][i],m[2][i],m[1][i]);
	}
}

