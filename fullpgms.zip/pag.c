#include<stdio.h>
void main()
{
	int msiz=20,psize,np,p[100],fn,ofs,ladd,padd,c=0,i;
	printf("Memory Size is %d\n",msiz);
	printf("Enter page size:");
	scanf("%d",&psize);
	np=msiz/psize;
	for(i=0;i<np;i++)
	{
		printf("Enter the frame of page %d:",i+1);
		scanf("%d",&p[i]);
	}
	do
	{
		printf("Enter a logical address:");
		scanf("%d",&ladd);
		fn=ladd/psize;
		ofs=ladd%psize;
		padd=(p[fn]*psize)+ofs;
		printf("Physical address is:%d\n",padd);
		printf("Do you want to continue(1/0)?:");
		scanf("%d",&c);
	}while(c==1);
}
