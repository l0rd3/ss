#include<stdio.h>
void main()
{
	int at[20],bt[20],rt[20],ct,i,flag=0,n,tq,time,rp;
	float wt=0,tat=0;
	printf("Input number of process:");
	scanf("%d",&n);
	rp=n;
	printf("Input time quantum:");
	scanf("%d",&tq);
	printf("Input the arrival time and burst time of each process:\n");
	for(i=0;i<n;i++)
	{
		printf("P[%d]",i+1);
		scanf("%d%d",&at[i],&bt[i]);
		rt[i]=bt[i];
	}
	printf("\nProcess\tTurnaround Time\tWaiting Time\n");
	for(i=0,ct=0;rp!=0;)
	{
		if(rt[i]<=tq && rt[i]>0)
		{
			ct=ct+rt[i];
			rt[i]=0;
			flag=1;
		}
		else if(rt[i]>0)
		{
			rt[i]=rt[i]-tq;
			ct=ct+tq;
		}
		if(rt[i]==0 && flag==1)
		{
			rp--;
			printf("%d\t%d\t\t%d\n",i+1,ct-at[i],ct-at[i]-bt[i]);
			wt=wt+ct-at[i]-bt[i];
			tat=tat+ct-at[i];
			flag=0;
		}
		if(i==n-1)
			i=0;
		else if(at[i+1]<=ct)
			i++;
		else
			i=0;
	}
	printf("Average Turnaround time:%f\n",wt/n);
	printf("Average Waiting Time:%f\n",tat/n);
}

