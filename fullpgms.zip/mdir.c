#include<stdio.h>
#include<string.h>
struct
{
	char dirname[10],fname[10][10];
	int fnum;
}dir[10];

void main()
{
	int i,n,c=0,dnum=0,j,fl;
	char ser[10],fer[10];
	do
	{
		fl=0;
		printf("MENU\n1.Create Directory\n2.Create file\n3.Search File\n4.Delete file\n5.Display\n");
		printf("Enter your choice: ");
		scanf("%d",&n);
		switch(n)
		{
			case 1:printf("Enter the directory name:\n");
			       scanf("%s",dir[dnum].dirname);
			       dir[dnum].fnum==0;
			       dnum++;
			       printf("Directory created\n");
			break;

			case 2:printf("Enter the directory name:\n");
			       scanf("%s",ser);
			       for(i=0;i<dnum;i++)
			       {
					if(strcmp(ser,dir[i].dirname)==0)
					{
						printf("Enter the file name:\n");
						scanf("%s",dir[i].fname[dir[i].fnum]);
			      	 	        dir[i].fnum++;
						break;
					}
			       }
			       if(i==dnum)
			       {
					printf("Directory not found\n");
			       }
			break;

			case 3:printf("Enter the directory name:\n");
                               scanf("%s",ser);
                               for(i=0;i<dnum;i++)
                               {
                                        if(strcmp(ser,dir[i].dirname)==0)
                                        {
						printf("Enter the file name to be searched:\n");
			       			scanf("%s",fer);
			       			for(j=0;j<dir[i].fnum;j++)
			       			{
							if(strcmp(fer,dir[i].fname[j])==0)
							{
								printf("File found at location %d\n",j);
								fl=1;
								break;
							}
						}
						if(j==dir[i].fnum)
						{
							printf("File not found\n");
							break;
						}
					}if(fl==1)
						break;
				}
				if(i==dnum)
					printf("No Such directory exists.\n");
			 break;

			case 4:printf("Enter the directory name:\n");
                               scanf("%s",ser);
                               for(i=0;i<dnum;i++)
                               {
                                        if(strcmp(ser,dir[i].dirname)==0)
                                        {
						printf("Enter the file name to be deleted:\n");
                               			scanf("%s",fer);
                               			for(j=0;j<dir[i].fnum;j++)
                               			{
                                        		if(strcmp(fer,dir[i].fname[j])==0)
                                        		{
								printf("File deleted\n");
								strcpy(dir[i].fname[j],dir[i].fname[dir[i].fnum-1]);
								dir[i].fnum--;
								fl=1;
								break;
							}
						}
						if(j==dir[i].fnum && fl==0)
	                                        {
         	                                	 printf("File not found\n");
                	                                 break;
                        	                 }
                                 	 }
					 if(fl==1)
					 	break;
				}
				if(i==dnum)
					printf("Directory not found\n");
			break;
			case 5:printf("The files are:\n");
		               for(i=0;i<dnum;i++)
			       {
			       		printf("The contents of Directory %s are:\n",dir[i].dirname);
			       		for(j=0;j<dir[i].fnum;j++)
			       		{
						printf("%s\t",dir[i].fname[j]);
			       		}
					printf("\n");
			       }
		 	break;
			default: printf("invalid option\n");
		}
		printf("Enter 1 to return to menu:\t");
		scanf("%d",&c);
	}while(c==1);

}
