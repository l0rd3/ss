#include<stdio.h>
void main()
{
	int bt[20],wt[20],tat[20],p[20],pr[20],t,i,j,n;
	float awt=0,atat=0;
	printf("Input the number of process:");
	scanf("%d",&n);
	printf("Input the burst time of each process and priority:\n");
	for(i=0;i<n;i++)
	{
		printf("P[%d]:",i+1);
		scanf("%d%d",&bt[i],&pr[i]);
		p[i]=i+1;
	}
	for(i=0;i<n;i++)
	{
		for(j=i+1;j<n;j++)
		{
			if(pr[i]>pr[j])
			{
				t=pr[i];
				pr[i]=pr[j];
				pr[j]=t;
				t=bt[i];
				bt[i]=bt[j];
				bt[j]=t;
				t=p[i];
				p[i]=p[j];
				p[j]=t;
			}
		}
	}
	wt[0]=0;
	for(i=1;i<n;i++)
	{
		wt[i]=wt[i-1]+bt[i-1];
		awt=awt+wt[i];
	}
	for(i=0;i<n;i++)
	{
		tat[i]=bt[i]+wt[i];
		atat=atat+tat[i];
	}
	atat=atat/n;
	awt=awt/n;
	printf("\nProcess\tPriority\tBurst time\tWaiting time\tTurnaround Time\n");
	for(i=0;i<n;i++)
	{
		printf("%d\t%d\t\t%d\t\t%d\t\t%d\n",p[i],pr[i],bt[i],wt[i],tat[i]);
	}
	printf("Average waiting time:%f\n",awt);
	printf("Average turnaround time:%f\n",atat);
}

