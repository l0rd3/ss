#include <stdio.h>
int current[5][5],maximum_claim[5][5],available[5],need[5][5];
int allocation[5]={0,0,0,0,0};
int maxres[5],running[5],safe=0;
int counter=0,i,j,exec,res,n,k=1;
void main()
{
	printf("\nEnter number of processes: ");
	scanf("%d", &n);
	for (i=0;i<n;i++)
	{
		running[i] = 1;
		counter++;
	}
	printf("\nEnter number of resources: ");
	scanf("%d", &res);
	printf("\nEnter available no of each resource:");
	for (i=0;i<res;i++)
	{
		scanf("%d", &maxres[i]);
	}
	printf("\nEnter Allocated Resource Table:\n");
	for (i = 0; i < n; i++)
	{
		for(j = 0; j < res; j++)
		{
			scanf("%d", &current[i][j]);
		}
	}
	printf("\nEnter Maximum Claim Table:\n");
	for (i = 0; i < n; i++)
	{
		for(j = 0; j < res; j++)
			scanf("%d", &maximum_claim[i][j]);
	}
	printf("\nThe Total available resources is: ");
	for (i=0;i<res;i++)
		printf("\t%d", maxres[i]);
	printf("\nThe Allocated Resource Table:\n");
	for (i = 0; i <n; i++)
	{
		for (j = 0; j < res; j++)
			printf("\t%d", current[i][j]);
		printf("\n");
	}
	printf("\nThe Maximum Claim Table:\n");
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < res; j++)
			printf("\t%d", maximum_claim[i][j]);
		printf("\n");
	}
	printf("The need matrix is:\n");
	for(i=0;i<n;i++)
	{
		for(j=0;j<res;j++)
		{
			need[i][j]=maximum_claim[i][j] - current[i][j];
			printf("%d\t",need[i][j]);
		}printf("\n");
	}
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < res; j++)
			allocation[j] += current[i][j];
	}
	printf("\nAllocated resources:");
	for (i = 0; i < res; i++)
		printf("\t%d", allocation[i]);
	for (i = 0; i < res; i++)
		available[i] = maxres[i] - allocation[i];
	printf("\nAvailable resources:");
	for (i = 0; i < res; i++)
		printf("\t%d", available[i]);
	printf("\n");
	while (counter != 0)
	{
		safe = 0;
		for (i = 0; i < n; i++)
		{
			if (running[i])
			{
				exec = 1;
				for (j = 0; j < res; j++)
				{
					if (maximum_claim[i][j] - current[i][j] > available[j])
					{
						exec = 0;
						break;
					}
				}
				if (exec)
				{
					printf("\nProcess%d is executing\n", i + 1);
					running[i] = 0;
					counter--;
					safe = 1;
					for (j = 0; j < res; j++)
						available[j] += current[i][j];
					break;
				}
			}
		}
		if (!safe)
		{
			printf("\nThe processes are in unsafe state.\n");
			break;
		}
		else
		{
			printf("\nThe process is in safe state");
			printf("\nAvailable vector:");
			for (i = 0; i < res; i++)
				printf("\t%d", available[i]);
			printf("\n");
		}
	}
}
