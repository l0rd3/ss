#include<stdio.h>
#include<stdlib.h>
#include<string.h>
void main()
{
char line[20],label[20],opcode[20],operand[20],opname[20],code[20],s[10],y[10];
        unsigned int locctr=0,strtadd=0,a;
        int j=0,i,number,flag=0;
        FILE *input,*inter,*stab,*otab;
        input=fopen("input.txt","r");
        inter=fopen("inter.txt","w");
        stab=fopen("symtab.txt","w");
        otab=fopen("optab.txt","r");
        printf("PASS1\n");
        fscanf(input,"%s%s%x",label,opcode,&strtadd);
        if((!strcmp(opcode,"START")))
        {
                locctr=strtadd;
                fscanf(input,"%s%s%s",label,opcode,operand);
        }
	while(strcmp(opcode,"END"))
	{	fprintf(inter,"%x %s %s %s\n",locctr,label,opcode,operand);
		if(strcmp(label,"**"))
		{
			fprintf(stab,"%s %x\n",label,locctr);
		}
		while((fscanf(otab,"%s%s",opname,code))>0)
			{
				if(!strcmp(opcode,opname))
				{	flag=1;
				}
			}
			if(flag==1)
			{
			  locctr=locctr+3;
			  flag=0;
			  rewind(otab);
			}
			else{
					a=atoi(operand);
					if(strcmp(opcode,"WORD")==0)
						locctr+=3;
					else if(strcmp(opcode,"RESW")==0)
						locctr+=3*a;
					else if(strcmp(opcode,"RESB")==0)
						locctr+=a;
					else if(strcmp(opcode,"BYTE")==0)
						locctr+=1;
					else
					{
						printf("input error");
						exit(0);
					}
		}
		fscanf(input,"%s%s%s",label,opcode,operand);
	}
	fprintf(inter,"00  %s %s %s\n",label,opcode,operand);
	printf("Intermmediate File generated.\n");
	fclose(input);
	fclose(stab);
	fclose(otab);
	fclose(inter);
}
