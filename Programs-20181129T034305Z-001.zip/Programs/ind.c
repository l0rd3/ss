#include<stdio.h>
#include<stdlib.h>
#include<time.h>
void main()
{
	int fi[50],p,b=50,i,j,c=1,k=0,n,ib,ind[10][50],sz[10];
	for(i=1;i<=50;i++)
		fi[i]=0;
	srand(time(0));
	do
	{
		printf("Input the size of file:");
		scanf("%d",&n);
		sz[k]=n;
		j=0;
		if(n<=b)
		{
			for(i=1;i<=50;i++)
			{
				p=rand()%51;
				if(fi[p]==0)
				{
					ind[k][j]=p;
					fi[p]=1;
					b--;
					j++;
				}
				if(j==n)
				{
					printf("\nFile allocated.\n");
					k++;
					break;
				}
			}
		}
		else
		{
			printf("\nSize exceeded.No blocks available.\n");
		}
		printf("Do you want to continue?1-yes,0-no::");
		scanf("%d",&c);
	}while(c==1);
	printf("The index table for each file is:\n");
	for(i=0;i<k;i++)
	{
		printf("File %d:\n",i+1);
		for(j=0;j<sz[i];j++)
		{
			printf("%d\t",ind[i][j]);
		}
		printf("\n");
	}
}
