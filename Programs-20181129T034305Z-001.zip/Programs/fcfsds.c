#include<stdio.h>
#include<stdlib.h>
void main()
{
	int q[100],n,head,i,j,k,seek=0,diff;
	float avg;
	printf("Enter the size of Queue:");
	scanf("%d",&n);
	printf("Enter the Queue:\n");
	for(i=1;i<=n;i++)
	{
		scanf("%d",&q[i]);
	}
	printf("Enter the initial head position: ");
	scanf("%d",&head);
	q[0]=head;
	printf("\n");
	for(j=0;j<=n-1;j++)
	{
		diff=abs(q[j+1]-q[j]);
		seek+=diff;
		printf("%d --> %d : Seek=%d\n",q[j],q[j+1],diff);
	}
	printf("\nTotal Seek Time=%d\n",seek);
}
