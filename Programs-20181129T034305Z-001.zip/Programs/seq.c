#include<stdio.h>
void main()
{
	int st,len,f[50],i,j,n=0,limit,flag=0;
	for(i=0;i<50;i++)
	{
		f[i]=0;
	}
	do
	{
		printf("Input the starting block:");
		scanf("%d",&st);
        	printf("Input the length of file:");
        	scanf("%d",&len);
		do
		{
			limit=st+len;
			for(j=st;j<limit;j++)
			{
				if(f[j]==0)
				{
					flag=0;
					continue;
				}
				else
				{
					flag=1;
					st=j+1;
					break;
				}
			}
		}while((st+len<=50)&&(flag==1));
		if(flag==0)
		{
			for(j=st;j<limit;j++)
			{
				if(f[j]==0)
				{
					f[j]=1;
					printf("\n%d\tallocated",j);
				}
			}
			if(j==(st+len))
        		printf("\nFile is allocated\n");
		}
		else
		{
			printf("Block cannot be allocated\n");
		}
		printf("Do you want to continue?1-yes,0-no::\t");
		scanf("%d",&n);
	}
	while(n==1);
}
